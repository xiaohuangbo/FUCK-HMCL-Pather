/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2026  huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.ui.instances;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialogLayout;
import com.jfoenix.controls.JFXListView;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import org.jackhuang.hmcl.game.HMCLGameInstance;
import org.jackhuang.hmcl.setting.BackgroundType;
import org.jackhuang.hmcl.setting.LauncherSettings;
import org.jackhuang.hmcl.setting.SettingsManager;
import org.jackhuang.hmcl.task.Schedulers;
import org.jackhuang.hmcl.task.Task;
import org.jackhuang.hmcl.ui.*;
import org.jackhuang.hmcl.ui.animation.ContainerAnimations;
import org.jackhuang.hmcl.ui.animation.TransitionPane;
import org.jackhuang.hmcl.ui.construct.*;
import org.jackhuang.hmcl.util.i18n.I18n;
import org.jackhuang.hmcl.util.io.FileUtils;
import org.jackhuang.hmcl.util.javafx.ItemPropertyAsyncCache;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Stream;

import static org.jackhuang.hmcl.ui.FXUtils.ignoreEvent;
import static org.jackhuang.hmcl.ui.ToolbarListPageSkin.createToolbarButton2;
import static org.jackhuang.hmcl.util.i18n.I18n.i18n;
import static org.jackhuang.hmcl.util.logging.Logger.LOG;

/// Lists screenshots of the current game instance and provides preview and file actions.
public final class ScreenshotsPage extends ListPageBase<ScreenshotsPage.Screenshot> {

    private final WeakListenerHolder listenerHolder = new WeakListenerHolder();

    private @Nullable Path screenshotsDir;

    public ScreenshotsPage(ObservableValue<? extends HMCLGameInstance.Optional> instanceContext) {
        Objects.requireNonNull(instanceContext, "instanceContext");

        listenerHolder.add(FXUtils.onWeakChangeAndOperate(instanceContext, current -> {
            if (current != null) {
                loadInstance(current);
            }
        }));
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ScreenshotsPageSkin(this);
    }

    public void loadInstance(HMCLGameInstance.Optional instance) {
        HMCLGameInstance gameInstance = instance.instance();
        if (gameInstance == null) return;
        screenshotsDir = gameInstance.getRunDirectory().resolve("screenshots");
        refresh();
    }

    public void refresh() {
        if (screenshotsDir == null) return;
        setLoading(true);
        Task.supplyAsync(Schedulers.io(), () -> {
            if (screenshotsDir == null) return List.<Screenshot>of();
            try (Stream<Path> stream = Files.list(screenshotsDir)) {
                return stream.map(Screenshot::fromFile).filter(Objects::nonNull).sorted(Comparator.reverseOrder()).toList();
            }
        }).whenComplete(Schedulers.javafx(), (list, exception) -> {
            if (exception != null) {
                LOG.warning("Failed to load screenshots in: " + screenshotsDir, exception);
                getItems().clear();
            } else {
                getItems().setAll(list);
            }
            setLoading(false);
        }).start();
    }

    private void revealFolder() {
        if (screenshotsDir != null) FXUtils.openFolder(screenshotsDir);
    }

    private void deleteAt(Path path) {
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            LOG.warning("Failed to delete screenshot: " + path, e);
        }
    }

    private void delete(Screenshot screenshot) {
        deleteAt(screenshot.getPath());
        refresh();
    }

    private void delete(Collection<Screenshot> screenshots) {
        screenshots.stream().map(Screenshot::getPath).forEach(this::deleteAt);
        refresh();
    }

    private void clear() {
        if (screenshotsDir == null) return;
        try (var stream = Files.list(screenshotsDir)) {
            stream.filter(Screenshot::isFileScreenshot).forEach(this::deleteAt);
        } catch (IOException e) {
            LOG.warning("Failed to clear screenshots at: " + screenshotsDir, e);
        }
        refresh();
    }

    private void selectDate(JFXListView<Screenshot> listView) {
        FXUtils.chooseDateRange(pair -> {
            Instant from = pair.key() != null ? pair.key().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant() : Instant.MIN;
            Instant to = pair.value() != null ? pair.value().plusDays(1).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant() : Instant.MAX;
            if (from.compareTo(to) >= 0) return;
            List<Screenshot> items = listView.getItems();
            int start = -1, end = -1;
            for (int i = 0; i < items.size(); i++) {
                // Reversed order
                var creationTime = items.get(i).getCreationTime();
                if ((creationTime == null || creationTime.compareTo(from) < 0) && end < 0) end = i;
                if ((creationTime == null || creationTime.compareTo(to) < 0) && start < 0) start = i;
            }
            if (start < 0) return;
            if (end < 0) end = items.size();
            listView.getSelectionModel().selectRange(start, end);
            listView.scrollTo(start);
        });
    }

    /// Describes a screenshot file and loads its preview images on demand.
    public static final class Screenshot implements Comparable<Screenshot> {
        private final Path path;
        private final String fileName;
        private final BasicFileAttributes attributes;

        /// Caches asynchronous thumbnail loads with a soft reference.
        private final ItemPropertyAsyncCache<@Nullable Image, Screenshot> thumbnailCache =
                new ItemPropertyAsyncCache.Soft<>(this, this::loadThumbnail, null);

        /// Retains the full image after a successful load, or is null before one succeeds.
        private @Nullable Image fullImage;

        public static boolean isFileScreenshot(Path path) {
            return Files.isRegularFile(path) && "png".equalsIgnoreCase(FileUtils.getExtension(path));
        }

        public static Screenshot fromFile(Path path) {
            if (!isFileScreenshot(path)) return null;
            BasicFileAttributes attr = null;
            try {
                attr = Files.readAttributes(path, BasicFileAttributes.class);
            } catch (IOException e) {
                LOG.warning("Failed to read screenshot attributes at: " + path, e);
            }
            return new Screenshot(path, FileUtils.getName(path), attr);
        }

        public Screenshot(Path path, String fileName, BasicFileAttributes attributes) {
            this.path = path;
            this.fileName = fileName;
            this.attributes = attributes;
        }

        public Path getPath() {
            return path;
        }

        public String getFileName() {
            return fileName;
        }

        public BasicFileAttributes getAttributes() {
            return attributes;
        }

        public Instant getCreationTime() {
            if (attributes == null) return null;
            return attributes.creationTime().toInstant();
        }

        public long getFileSize() {
            if (attributes == null) return -1;
            return attributes.size();
        }

        public boolean isFullImageLoaded() {
            return fullImage != null;
        }

        /// Loads an aspect-ratio-preserving thumbnail bounded by 72 by 72 pixels.
        ///
        /// @return the thumbnail, or null if loading throws an exception
        @Nullable
        private Image loadThumbnail() {
            try {
                return FXUtils.loadImage(path, 72, 72, true, false);
            } catch (Exception e) {
                LOG.warning("Failed to load screenshot thumbnail at: " + path, e);
                return null;
            }
        }

        @Nullable
        public Image getFullImage() {
            if (fullImage == null) {
                try {
                    fullImage = FXUtils.loadImage(path);
                } catch (Exception e) {
                    LOG.warning("Failed to load screenshot content at: " + path, e);
                }
            }
            return fullImage;
        }

        @Override
        public boolean equals(Object obj) {
            return obj instanceof Screenshot that && Objects.equals(this.path, that.path);
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(path);
        }

        @Override
        public int compareTo(@NotNull ScreenshotsPage.Screenshot o) {
            return this.path.compareTo(o.path);
        }

    }

    /// Displays a screenshot thumbnail, metadata, and file actions in a reusable cell.
    private static final class ScreenshotCell extends MDListCell<Screenshot> {

        /// Holds the thumbnail or the placeholder icon when no thumbnail is available.
        private final StackPane imagePane = new StackPane();
        /// Receives the cached thumbnail for the current item.
        private final ObjectProperty<@Nullable Image> thumbnail = new SimpleObjectProperty<>();
        /// Displays the screenshot file name and creation time.
        private final TwoLineListItem content = new TwoLineListItem();

        /// Creates a cell whose file actions operate on the supplied page.
        public ScreenshotCell(JFXListView<Screenshot> listView, ScreenshotsPage page) {
            super(listView);

            setSelectable();

            FXUtils.onChangeAndOperate(thumbnail, image -> imagePane.getChildren().setAll(
                    image == null ? SVG.SCREENSHOT_MONITOR.createIcon(36) : new ImageContainer(image, 36, 36)));

            HBox container = new HBox(8);
            container.setPickOnBounds(false);
            container.setAlignment(Pos.CENTER_LEFT);

            content.setMouseTransparent(true);
            HBox.setHgrow(content, Priority.ALWAYS);

            JFXButton copyButton = FXUtils.newToggleButton4(SVG.CONTENT_COPY);
            copyButton.setOnAction(e -> {
                @Nullable Screenshot screenshot = getItem();
                if (screenshot != null) {
                    @Nullable Image image = screenshot.getFullImage();
                    if (image != null) FXUtils.copyImage(image);
                }
            });

            JFXButton revealButton = FXUtils.newToggleButton4(SVG.FOLDER);
            revealButton.setOnAction(e -> {
                @Nullable Screenshot screenshot = getItem();
                if (screenshot != null) {
                    FXUtils.showFileInExplorer(screenshot.getPath());
                }
            });

            JFXButton infoButton = FXUtils.newToggleButton4(SVG.INFO);
            infoButton.setOnAction(e -> {
                @Nullable Screenshot screenshot = getItem();
                if (screenshot != null) {
                    Controllers.dialog(new ScreenshotDialog(screenshot));
                }
            });
            FXUtils.onDoubleClicked(this, infoButton::fire);

            JFXButton deleteButton = FXUtils.newToggleButton4(SVG.DELETE_FOREVER);
            deleteButton.setOnAction(e -> {
                @Nullable Screenshot screenshot = getItem();
                if (screenshot != null) {
                    Controllers.confirm(i18n("button.remove.confirm"), i18n("button.remove"),
                            () -> page.delete(screenshot), null);
                }
            });

            container.getChildren().setAll(imagePane, content, copyButton, revealButton, infoButton, deleteButton);

            StackPane.setMargin(container, new Insets(8));
            getContainer().getChildren().setAll(container);
        }

        /// Attaches the current item's cached thumbnail and updates its metadata.
        /// Clears the displayed thumbnail when the cell becomes empty.
        @Override
        protected void updateControl(@Nullable Screenshot item, boolean empty) {
            if (item == null || empty) {
                thumbnail.set(null);
                return;
            }

            item.thumbnailCache.attachValue(thumbnail, new WeakReference<>(itemProperty()));

            content.setTitle(item.getFileName());
            @Nullable Instant creationTime = item.getCreationTime();
            if (creationTime != null) content.setSubtitle(I18n.formatDateTime(creationTime));
        }
    }

    private static final class ScreenshotDialog extends JFXDialogLayout {

        public ScreenshotDialog(Screenshot screenshot) {
            TwoLineListItem head = new TwoLineListItem();
            head.setTitle(screenshot.getFileName());
            setHeading(head);

            var image = screenshot.getFullImage();
            if (image == null) {
                setBody(SVG.SCREENSHOT_MONITOR.createIcon(360));
                if (screenshot.getAttributes() != null)
                    head.setSubtitle(I18n.formatDateTime(screenshot.getCreationTime()) + "    " + FileUtils.parseFileSize(screenshot.getFileSize()));
            } else {
                setBody(new ImageContainer(image, Math.min(Controllers.getDecorator().contentWidthProperty().get() * 0.8, image.getWidth()), Controllers.getDecorator().contentHeightProperty().get() * 0.57));
                if (screenshot.getAttributes() != null)
                    head.setSubtitle(
                            I18n.formatDateTime(screenshot.getCreationTime())
                                    + "    " + FileUtils.parseFileSize(screenshot.getFileSize())
                                    + "    " + (int) image.getWidth() + " * " + (int) image.getHeight()
                    );
                else head.setSubtitle((int) image.getWidth() + " * " + (int) image.getHeight());
            }

            JFXButton setAsBgButton = new JFXButton(i18n("screenshots.set_as_bg"));
            setAsBgButton.getStyleClass().add("dialog-accept");
            setAsBgButton.setOnAction(e -> {
                SettingsManager.settings().getThemeAppearanceOverrides().add(LauncherSettings.THEME_APPEARANCE_BACKGROUND);
                SettingsManager.settings().backgroundTypeProperty().set(BackgroundType.CUSTOM);
                SettingsManager.settings().customBackgroundImagePathProperty().set(screenshot.getPath().toString());
            });

            JFXButton copyButton = new JFXButton(i18n("menu.copy"));
            copyButton.getStyleClass().add("dialog-accept");
            copyButton.setDisable(image == null);
            copyButton.setOnAction(e -> {
                if (image != null) FXUtils.copyImage(image);
            });

            JFXButton okButton = new JFXButton(i18n("button.ok"));
            okButton.getStyleClass().add("dialog-accept");
            okButton.setOnAction(e -> fireEvent(new DialogCloseEvent()));
            FXUtils.onEscPressed(this, okButton::fire);
            setActions(setAsBgButton, copyButton, okButton);
        }
    }

    private static final class ScreenshotsPageSkin extends SkinBase<ScreenshotsPage> {

        private final TransitionPane toolbarPane;
        private final HBox toolbarNormal;
        private final HBox toolbarSelecting;

        private final JFXListView<Screenshot> listView;

        public ScreenshotsPageSkin(ScreenshotsPage skinnable) {
            super(skinnable);

            StackPane pane = new StackPane();
            pane.setPadding(new Insets(10));
            pane.getStyleClass().addAll("notice-pane");

            ComponentList root = new ComponentList();
            root.getStyleClass().add("no-padding");
            listView = new JFXListView<>();
            listView.getStyleClass().add("no-horizontal-scrollbar");

            {
                toolbarPane = new TransitionPane();

                toolbarNormal = new HBox();
                toolbarSelecting = new HBox();

                // Toolbar Normal
                toolbarNormal.getChildren().setAll(
                        createToolbarButton2(i18n("button.refresh"), SVG.REFRESH, skinnable::refresh),
                        createToolbarButton2(i18n("button.reveal_dir"), SVG.FOLDER_OPEN, skinnable::revealFolder),
                        createToolbarButton2(i18n("button.clear"), SVG.DELETE_FOREVER, () -> {
                            Controllers.confirm(i18n("screenshots.clear.confirm"), i18n("button.clear"), skinnable::clear, null);
                        }),
                        createToolbarButton2(i18n("button.select_date"), SVG.DATE_RANGE, () -> skinnable.selectDate(listView))
                );

                // Toolbar Selecting
                toolbarSelecting.getChildren().setAll(
                        createToolbarButton2(i18n("menu.copy"), SVG.FOLDER_COPY, () -> {
                            FXUtils.copyFiles(listView.getSelectionModel().getSelectedItems().stream().map(Screenshot::getPath).toList());
                        }),
                        createToolbarButton2(i18n("button.remove"), SVG.DELETE_FOREVER, () -> {
                            Controllers.confirm(i18n("button.remove.confirm"), i18n("button.remove"), () ->
                                    skinnable.delete(listView.getSelectionModel().getSelectedItems()), null);
                        }),
                        createToolbarButton2(i18n("button.select_all"), SVG.SELECT_ALL, () ->
                                listView.getSelectionModel().selectAll()),
                        createToolbarButton2(i18n("button.cancel"), SVG.CANCEL, () ->
                                listView.getSelectionModel().clearSelection())
                );

                FXUtils.onChangeAndOperate(listView.getSelectionModel().selectedItemProperty(),
                        selectedItem -> {
                            if (selectedItem == null)
                                changeToolbar(toolbarNormal);
                            else
                                changeToolbar(toolbarSelecting);
                        });
                root.getContent().add(toolbarPane);

                // Clear selection when pressing ESC
                root.addEventHandler(KeyEvent.KEY_PRESSED, e -> {
                    if (e.getCode() == KeyCode.ESCAPE) {
                        if (listView.getSelectionModel().getSelectedItem() != null) {
                            listView.getSelectionModel().clearSelection();
                            e.consume();
                        }
                    }
                });
            }

            {
                SpinnerPane center = new SpinnerPane();
                ComponentList.setVgrow(center, Priority.ALWAYS);
                center.loadingProperty().bind(skinnable.loadingProperty());

                listView.setCellFactory(x -> new ScreenshotCell(listView, skinnable));
                listView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
                Bindings.bindContent(listView.getItems(), skinnable.getItems());

                listView.setOnContextMenuRequested(event -> {
                    Screenshot selectedItem = listView.getSelectionModel().getSelectedItem();
                    if (selectedItem != null && listView.getSelectionModel().getSelectedItems().size() == 1) {
                        listView.getSelectionModel().clearSelection();
                        Controllers.dialog(new ScreenshotDialog(selectedItem));
                    }
                });

                // ListViewBehavior would consume ESC pressed event, preventing us from handling it
                // So we ignore it here
                ignoreEvent(listView, KeyEvent.KEY_PRESSED, e -> e.getCode() == KeyCode.ESCAPE);

                center.setContent(listView);
                root.getContent().add(center);
            }

            pane.getChildren().setAll(root);
            getChildren().setAll(pane);
        }

        private void changeToolbar(HBox newToolbar) {
            if (newToolbar != toolbarPane.getCurrentNode()) toolbarPane.setContent(newToolbar, ContainerAnimations.FADE);
        }
    }

}
